package org.example.crud;



import org.example.crud.bootstrap.InitDatabase;
import org.example.crud.dao.AccountDao;
import org.example.crud.model.Account;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;


public class Client {
    public static void main(String[] args) throws ClassNotFoundException {
        Logger logger = Logger.getLogger("JDBC-CRUD");
        // Creates the table "CUSTOMERS"
        InitDatabase.init();
        AccountDao repository = new AccountDao();
        // Create a new Customer model and stores it using the repository method
        Account dummy = new Account();
        dummy.setTitular("Alessio");
        dummy.setCantidad(100);
        dummy.setTipo("Ahorro");
        repository.save(dummy);

        // Create a new Customer model and stores it using the repository method
        dummy = new Account();
        dummy.setTitular("Francho");
        dummy.setCantidad(100.00);
        dummy.setTipo("Corriente");
        repository.save(dummy);

        // Fetch all data from the table
        List<Account> res = repository.findAll();
        //logger.info(res.toString());
        System.out.println(res.toString());

        Optional<Account> cuenta = repository.findById(Long.parseLong("1"));
        //logger.info(cuenta.toString());
        System.out.println(cuenta.toString());

        Account cuenta1 = new Account();
        cuenta1.setId(res.get(0).getId());
        cuenta1.setTitular(res.get(0).getTitular());
        cuenta1.setCantidad(150.00);
        cuenta1.setTipo(res.get(0).getTipo());
        repository.update(cuenta1);

        Optional<Account> cuenta2 = repository.findById(Long.parseLong("1"));
        //logger.info(cuenta2.toString());
        System.out.println(cuenta2.toString());

        repository.deleteAll();
        List<Account> res1 = repository.findAll();
        //logger.info(res1.toString());
        System.out.println(res1.toString());
    }


}

