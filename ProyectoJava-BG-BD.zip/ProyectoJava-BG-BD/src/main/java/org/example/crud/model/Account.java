package org.example.crud.model;

import java.io.Serializable;
import java.util.Objects;

public class Account implements Serializable {

    private Long id;
    private String titular;
    private double cantidad;
    private String tipo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Account user = (Account) o;
        return Objects.equals(id, user.id) && Objects.equals(titular, user.titular) && Objects.equals(cantidad, user.cantidad) && Objects.equals(tipo, user.tipo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, titular, cantidad, tipo);
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", titular='" + titular + '\'' +
                ", cantidad='" + cantidad + '\'' +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}
