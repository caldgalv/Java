package org.example.crud.mapper;

import org.example.crud.model.Account;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountMapper implements BaseMapper<Account> {
    @Override
    public Account toModel(ResultSet resultSet) {
        Account account = new Account();
        try {
            account.setId(resultSet.getLong("ID"));
            account.setTitular(resultSet.getString("TITULAR"));
            account.setCantidad(resultSet.getDouble("CANTIDAD"));
            account.setTipo(resultSet.getString("TIPO"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return account;
    }
}
