package org.example.crud.dao;


import org.example.crud.db.DBConnection;
import org.example.crud.mapper.AccountMapper;
import org.example.crud.model.Account;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class AccountDao implements CrudDao<Account, Long> {

    private Connection connection;
    private AccountMapper mapper;

    public AccountDao(){
        this.connection = DBConnection.getConnection();
        this.mapper = new AccountMapper();
    }

    @Override
    public void save(Account model) {
        String insertUserQuery = "INSERT INTO accounts (TITULAR,CANTIDAD,TIPO) VALUES (?,?,?)";

        try(PreparedStatement preparedStatement = connection.prepareStatement(insertUserQuery)){
            preparedStatement.setString(1,model.getTitular());
            preparedStatement.setDouble(2,model.getCantidad());
            preparedStatement.setString(3,model.getTipo());
            preparedStatement.executeUpdate();
        }catch (SQLException e ){
            e.printStackTrace();
        }
    }

    @Override
    public Optional<Account> findById(Long id) {
        String selectByIdQuery = "SELECT * FROM accounts WHERE ID = ?";
        Account account = null;
        try(PreparedStatement preparedStatement = connection.prepareStatement(selectByIdQuery)){
            preparedStatement.setLong(1,id);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                account = mapper.toModel(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Objects.nonNull(account) ? Optional.of(account):Optional.empty();
    }

    @Override
    public List<Account> findAll() {
        String selectAllQuery = "SELECT * FROM accounts";
        List<Account> Accounts = new ArrayList<>();
        try(PreparedStatement preparedStatement = connection.prepareStatement(selectAllQuery)){
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                Account Account = mapper.toModel(resultSet);
                Accounts.add(Account);
            }
        }catch (SQLException e ){
            e.printStackTrace();
        }
        return Accounts;
    }

    @Override
    public Account update(Account model) {
        String updateAccountQuery = "UPDATE accounts SET TITULAR = ? , CANTIDAD = ? , TIPO = ? WHERE ID = ?";
        try(PreparedStatement preparedStatement = connection.prepareStatement(updateAccountQuery)){
            preparedStatement.setString(1,model.getTitular());
            preparedStatement.setDouble(2,model.getCantidad());
            preparedStatement.setString(3,model.getTipo());
            preparedStatement.setLong(4,model.getId());
            preparedStatement.executeUpdate();
        }catch (SQLException e ){
            e.printStackTrace();
        }
        //NOTE: This is actually not a good practice since the data could be manipulated by a trigger.
        return model;
    }

    @Override
    public void delete(Long id) {
        String deleteQuery = "DELETE FROM accounts WHERE ID = ?";
        try(PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)){
            preparedStatement.setLong(1,id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteAll() {
        String deleteQuery = "DELETE FROM accounts";
        try(PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)){
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
